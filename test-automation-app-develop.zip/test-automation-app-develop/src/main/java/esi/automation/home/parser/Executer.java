package esi.automation.home.parser;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import com.jagacy.Field;
import com.jagacy.Key;
import com.jagacy.Session3270;
import com.jagacy.util.JagacyException;
import com.jagacy.util.JagacyProperties;

import esi.automation.home.model.EachStepResponseResult;
import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.MainframeTestStep;
import esi.automation.home.model.ResponseResult;
import esi.automation.home.model.Step;
import esi.automation.home.model.WebStep;
import esi.automation.home.utils.AutomationUtils;
import esi.automation.home.utils.GrabScreenShots;

public class Executer extends Session3270 {

    static Logger log = Logger.getLogger(Executer.class);

   
    private JagacyProperties props;
    ResourceBundle configuration = null;
    MainframeTestCase testCase = null;

    List<Step> testSteps = null;
    List<EachStepResponseResult> responseResultList = new ArrayList<EachStepResponseResult>();
    HashMap<String, String> sessionData = new HashMap<String, String>();
    ResponseResult responseResult = new ResponseResult();

    private Executer(MainframeTestCase testCase) throws JagacyException, IOException {

        super("Test Execution");
        // log.info("Begin loading properties");
        this.testCase = testCase;

        props = getProperties();
        loadProps();
        Enumeration<?> e = configuration.getKeys();
        while (e.hasMoreElements()) {
            String key = (String) e.nextElement();
            String value = configuration.getString(key);
            props.set(key, value);
        }

        if (testCase.getScreenshot() != null && testCase.getScreenshot().equalsIgnoreCase("on")) {
            props.set("window", "true");
        } else {
            props.set("window", "false");
        }

        if (testCase.getHost() != null) {
            props.set("jagacy.host", testCase.getHost());
        } else {
            throw new JagacyException("Error Processing JSON Data, Host information incorrect !.");
        }

        if (testCase.getPort() != null) {
            props.set("jagacy.port", testCase.getPort());
        } else {
            throw new JagacyException("Error Processing JSON Data, Port information incorrect !.");
        }

        // log.info("Get Property window - " + props.get("window"));
        // log.info("End loading properties");
    }

    public static Executer getInstance(MainframeTestCase testCase) throws Exception {

        if (null == testCase)
            throw new Exception("stepList object is null");
        
        	Executer executer = new Executer(testCase);
            executer.testSteps = testCase.getTestSteps();
           
            return executer;
    }

    public ResponseResult execute() throws JagacyException {

        try {
            this.open();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            this.close();
        }
        responseResult.setResponseResultList(responseResultList);
        responseResult.setSessionData(sessionData);
        return responseResult;
    }

    @Override
    protected boolean logon() throws JagacyException {

        String validationFaliure = null;
        int debugValue = 3; // this variable is only used during bebug mode
                            // during step count.
        int fieldNumber = 0;

        int index = 0;

        for (Step step : this.testSteps) {

            String sessionKeyName = null;
            String sessionKeyValue = null;
            Field[] allFields = null;
            String testResult = "success";

            index++;
            if (step instanceof WebStep) {
                WebStep webStep = (WebStep) step;
                log.info("Processing - Step - " + index + " Operations :" + webStep.getWebStepName());
                WebDriver webdriver = null;
                // web part
                switch (webStep.getWebStepName()) {
                case "navigate":
                    WebUtility.Launch(webStep.getBrowser(), webStep.getWebUrl());
                    break;
                case "input":
                    WebUtility.Input(webStep.getSelectBy(), webStep.getElementName(), webStep.getValue(), "Yes", 0,
                            webStep.getSwitchToFrame());
                    break;
                case "click":
                    WebUtility.Click(webStep.getSelectBy(), webStep.getElementName(), "Yes", 100);
                    break;
                case "clickJS":
                    WebUtility.ClickJS(webStep.getSelectBy(), webStep.getElementName(), "Yes");
                    break;
                case "SelectJS":
                    WebUtility.SelectJS(webStep.getSelectBy(), webStep.getElementName(), "Yes");
                    break;   
                    
                case "Select":
                    WebUtility.Select(webStep.getSelectBy(), webStep.getElementName(), webStep.getValue(), "Yes", 100, webStep.getSwitchToFrame());
                    break;
                case "waitForElement":
                    WebUtility.WaitForElement(webStep.getSelectBy(), webStep.getElementName(), 10000);
                    break;
                case "alert":
                    WebUtility.alert(webStep.getAlertv());
                    break;
                case "getValue" :
                	WebUtility.getValue(webStep.getSwitchToFrame(), webStep.getSelectBy(), webStep.getElementName(), webStep.getValue(), "Yes", 100);
                	break;
                case "doAssert" :
                	Asserts.doAssert(webStep.getSelectBy(), webStep.getElementName(), webStep.getValue(), "Yes", 100);
                	break;
                	
                case "switchToWindow" :
                	WebUtility.switchToSubwindow(webStep.getSwitchToWin());

                }

                // close the driver
                // WebUtility.KillDriver();

            } else {
                MainframeTestStep testStep = (MainframeTestStep) step;
                log.info("Processing - Step - " + index + " - " + testStep.getStepName() + " Value - "
                        + testStep.getValue() + " * Label - " + testStep.getLabel() + " * LabelPosition - "
                        + testStep.getLabelPosition() + " * Co-ordinates - " + testStep.getRow() + "/"
                        + testStep.getColumn() + " * Key name - " + testStep.getKeyname() + " * Wait time - "
                        + testStep.getTimeInMillis() + " * Field Number - " + testStep.getField_no());

                if (testStep.getValue() != null && testStep.getValue().startsWith("$")){
                	testStep.setValue(sessionData.get(testStep.getValue()));
                }
                if (index == debugValue) {
                    // log.info("Executing - Steps Number - " + index);
                }

                try {
                    Thread.currentThread();
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    validationFaliure = e.getLocalizedMessage();
                }

                switch (testStep.getType()) {

                case Keywords.TEST_STEP_WAIT_FOR_CORDINATE:

                    props.set(("index" + index + ".wait.row"), Long.toString(testStep.getRow()));
                    props.set(("index" + index + ".wait.column"), Long.toString(testStep.getColumn()));
                    props.set(("index" + index + ".wait.value"), testStep.getValue());
                    props.set(("index" + index + ".timeout.seconds"), Long.toString(testStep.getTimeInMillis()));
                    try {
                        Thread.currentThread();
                        Thread.sleep(500);
                    } catch (InterruptedException e) {
                        validationFaliure = e.getLocalizedMessage();
                    }
                    waitForPosition("index" + index + ".wait", "index" + index + ".timeout.seconds");
                    break;

                case Keywords.TEST_STEP_WAIT_FOR_TIME:
                    props.set("index" + index + ".timeout.seconds", Long.toString(testStep.getTimeInMillis()));
                    waitForChange("index" + index + ".timeout.seconds");
                    break;

                case Keywords.TEST_STEP_WRITE_AT_CORDINATE:

                    props.set(("index" + index + ".entry.row"), Long.toString(testStep.getRow()));
                    props.set(("index" + index + ".entry.column"), Long.toString(testStep.getColumn()));
                    props.set(("index" + index + ".entry.value"), testStep.getValue());
                    writePosition("index" + index + ".entry", testStep.getValue());
                    break;

                case Keywords.TEST_STEP_WRITE_AT_LABEL:
                    if (testStep.getLabelPosition().equalsIgnoreCase("after")) {
                        if (testStep.getLabel().startsWith("%") && testStep.getLabel().endsWith("%")) {
                            writeAfterLabel(getFieldFullTextContains(testStep.getLabel()), testStep.getValue());
                        } else {
                            writeAfterLabel(testStep.getLabel(), testStep.getValue());
                        }
                    } else if (testStep.getLabelPosition().equalsIgnoreCase("before")) {
                        if (testStep.getLabel().startsWith("%") && testStep.getLabel().endsWith("%")) {
                            writeBeforeLabel(getFieldFullTextContains(testStep.getLabel()), testStep.getValue());
                        } else {
                            writeBeforeLabel(testStep.getLabel(), testStep.getValue());
                        }
                    } else {
                        validationFaliure = "Position should be defined for writting after/before  label : "
                                + testStep.getValue();
                        throw new JagacyException("Position should be defined for writting after/before  label : "
                                + testStep.getValue());
                    }
                    break;

                case Keywords.TEST_STEP_WRITE_AT_FIELD:
                    props.set(("index" + index + ".field"), Long.toString(testStep.getField_no()));
                    props.set(("index" + index + ".offset"), Long.toString(testStep.getOffset()));
                    props.set(("index" + index + ".length"), Long.toString(testStep.getLength()));
                    writeField("index" + index, testStep.getValue());
                    break;

                case Keywords.TEST_STEP_SEND_KEY_NAME:

                    if (testStep.getKeyname().equalsIgnoreCase("ENTER")) {
                        writeKey(Key.ENTER);
                    } else if (testStep.getKeyname().equalsIgnoreCase("PF5")) {
                        writeKey(Key.PF5);
                    }
                    break;

                case Keywords.TEST_STEP_READ_AT_LABEL:
                    allFields = readFields();

                    sessionKeyName = "$"+testStep.getValue();
                    fieldNumber = AutomationUtils.readFieldNumberByLabel(allFields, testStep.getLabel());

                    if (testStep.getLabelPosition().equalsIgnoreCase("before") && fieldNumber > 0) {
                        Long beforePosition = new Long(fieldNumber) - 1;
                        sessionKeyValue = AutomationUtils.readFieldDataByFieldNumber(allFields, beforePosition);
                    } else if (testStep.getLabelPosition().equalsIgnoreCase("after") && fieldNumber > 0) {
                        Long afterPosition = new Long(fieldNumber) + 1;
                        sessionKeyValue = AutomationUtils.readFieldDataByFieldNumber(allFields, afterPosition);
                    }
                    sessionKeyValue = sessionData.put(sessionKeyName, sessionKeyValue);
                    break;

                case Keywords.TEST_STEP_READ_AT_FIELDNUMBER:
                    allFields = readFields();
                    sessionKeyName = "$"+testStep.getValue();
                    sessionKeyValue = AutomationUtils.readFieldDataByFieldNumber(allFields, testStep.getField_no());
                    sessionData.put(sessionKeyName, sessionKeyValue);
                    break;

                case Keywords.TEST_STEP_READ_AT_CORDINATE:
                	String rowData = readRow(testStep.getRow().intValue());
                    sessionKeyName = "$"+testStep.getValue();
                    sessionKeyValue = rowData.substring(testStep.getColumn().intValue(), rowData.indexOf(" ", testStep.getColumn().intValue()));
                    sessionData.put(sessionKeyName, sessionKeyValue);
                    break;

                case Keywords.TEST_STEP_ASSERT_AT_CORDINATE:
                    rowData = readRow(testStep.getRow().intValue());
                    String screenData = rowData.substring(testStep.getColumn().intValue(), rowData.indexOf(" ", testStep.getColumn().intValue()));
                    boolean negativeAssert = testStep.getOperator()!=null && testStep.getOperator().equals("not_equal");
                                     
                    if (screenData.equals(testStep.getValue()) && !negativeAssert) {
                    	log.info("Assert - Step - " + index + " - " + testStep.getStepName() + " id: "
                                + testStep.getStepId() + " Assert Value: " + testStep.getValue() + " Actual Value  Found: " + screenData + " assert passed");
                    } else if(!screenData.equals(testStep.getValue()) && negativeAssert) {
                    	log.info("Assert - Step - " + index + " - " + testStep.getStepName() + " id: "
                                + testStep.getStepId() + " Assert Value: " + testStep.getValue() + " Actual Value  Found: " + screenData + " assert passed");
                    }else {
                    	log.info("Assert - Step - " + index + " - " + testStep.getStepName() + " id: "
                                + testStep.getStepId() + " Assert Value: " + testStep.getValue() + " Actual Value  Found: " + screenData + " assert failed");
                        testResult = "fail";
                    }
                    break;
                case Keywords.TEST_STEP_ASSERT_AT_LABEL:
                    allFields = readFields();
                    negativeAssert = testStep.getOperator()!=null && testStep.getOperator().equals("not_equal");
                    fieldNumber = AutomationUtils.readFieldNumberByLabel(allFields, testStep.getLabel());
                    screenData = "";
                    if (testStep.getLabelPosition().equalsIgnoreCase("before") && fieldNumber > 0) {
                        Long beforePosition = new Long(fieldNumber) - 1;
                        screenData = AutomationUtils.readFieldDataByFieldNumber(allFields, beforePosition);
                    } else if (testStep.getLabelPosition().equalsIgnoreCase("after") && fieldNumber > 0) {
                        Long afterPosition = new Long(fieldNumber) + 1;
                        screenData = AutomationUtils.readFieldDataByFieldNumber(allFields, afterPosition);
                    }
                                        
                    if (screenData.equals(testStep.getValue()) && !negativeAssert) {
                    	log.info("Assert - Step - " + index + " - " + testStep.getStepName() + " id: "
                                + testStep.getStepId() + " Assert Value: " + testStep.getValue() + " Actual Value  Found: " + screenData + " assert passed");
                    } else if(!screenData.equals(testStep.getValue()) && negativeAssert) {
                    	log.info("Assert - Step - " + index + " - " + testStep.getStepName() + " id: "
                                + testStep.getStepId() + " Assert Value: " + testStep.getValue() + " Actual Value  Found: " + screenData + " assert passed");
                    }else {
                    	log.info("Assert - Step - " + index + " - " + testStep.getStepName() + " id: "
                                + testStep.getStepId() + " Assert Value: " + testStep.getValue() + " Actual Value  Found: " + screenData + " assert failed");
                        testResult = "fail";
                    }
                    break;
                case Keywords.TEST_STEP_ASSERT_AT_FIELDNUMBER:
                    allFields = readFields();
                    negativeAssert = testStep.getOperator()!=null && testStep.getOperator().equals("not_equal");
                    screenData  = AutomationUtils.readFieldDataByFieldNumber(allFields, testStep.getField_no());
                                        
                    if (screenData.equals(testStep.getValue()) && !negativeAssert) {
                    	log.info("Assert - Step - " + index + " - " + testStep.getStepName() + " id: "
                                + testStep.getStepId() + " Assert Value: " + testStep.getValue() + " Actual Value  Found: " + screenData + " assert passed");
                    } else if(!screenData.equals(testStep.getValue()) && negativeAssert) {
                    	log.info("Assert - Step - " + index + " - " + testStep.getStepName() + " id: "
                                + testStep.getStepId() + " Assert Value: " + testStep.getValue() + " Actual Value  Found: " + screenData + " assert passed");
                    }else {
                    	log.info("Assert - Step - " + index + " - " + testStep.getStepName() + " id: "
                                + testStep.getStepId() + " Assert Value: " + testStep.getValue() + " Actual Value  Found: " + screenData + " assert failed");
                        testResult = "fail";
                    }
                    break;
                default:
                    validationFaliure = "Parameter Passed inside JSON is Incorrect, Step No/Name " + index + " - "
                            + testStep.getStepName();
                    throw new IllegalArgumentException(validationFaliure);
                }
                
                String urlToScreenShot = null;

                if (testCase != null && testCase.getScreenshot().equalsIgnoreCase("on")) {
                    try {
                        urlToScreenShot = GrabScreenShots.setScreenImage(index);
                    } catch (Exception e) {
                        addResponseResult(Integer.toString(index), "fail", urlToScreenShot, e.getLocalizedMessage());
                        e.printStackTrace();
                    }
                }
                addResponseResult(Integer.toString(index), testResult, urlToScreenShot, null);
                if("fail".equals(testResult)){
                	return true;
                }
            }
        }

        return true;
    }

    // Close jagacy processor terminal.
    @Override
    public void logoff() throws JagacyException {

        // this.close();
    }

    public void loadProps() throws IOException {

        configuration = ResourceBundle.getBundle("fixtures/jagacy/properties/jagacy");
    }

    private String getFieldFullTextContains(String value) throws JagacyException {

        String searchValue = value.replaceAll("%", " ").trim();
        Field field = null;
        Field[] fields = readFields();
        for (Field f : fields) {
            if (f.getValue().toUpperCase().contains(searchValue.toUpperCase())) {
                field = f;
            }
        }
        return field.getValue();
    }

    private void addResponseResult(String runID, String results, String urlToScreenShot, String validationFaliure) {

        EachStepResponseResult responseResult = new EachStepResponseResult();
        responseResult.setExecutionTime(AutomationUtils.getCurrentDateTimeHrsMillSec());
        responseResult.setResults(results);
        responseResult.setRunID(runID);
        if (urlToScreenShot != null) {
            responseResult.setUrlToScreenShot(urlToScreenShot);
        }
        if (validationFaliure != null) {
            responseResult.setValidationFaliure(validationFaliure);
        }

        responseResultList.add(responseResult);

    }
}