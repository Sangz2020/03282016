/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.service;

import org.apache.log4j.Logger;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.springframework.stereotype.Service;

import esi.automation.home.model.ResponseResult;
import esi.automation.home.parser.Executer;
import esi.automation.home.parser.Parser;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
@Service
public class ProcessTestCaseServiceImpl implements ProcessTestCaseService {

    /*
     * (non-Javadoc)
     * 
     * @see
     * esi.automation.home.service.ProcessTestCase#readAndExecuteSteps(java.
     * lang.String)
     */
    static Logger log = Logger.getLogger(ProcessTestCaseServiceImpl.class);

    @Override
    public ResponseResult readAndExecuteSteps(String jsonTestSteps) {

        ResponseResult responseResult = null;
        Executer executor = null;

        try {

            JSONParser parser = new JSONParser();
            JSONObject jsonObject = (JSONObject) parser.parse(jsonTestSteps);
            Parser testautomationParser = new Parser();
            executor = Executer.getInstance(testautomationParser.parse(jsonObject));
            responseResult = executor.execute();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return responseResult;
    }
}
