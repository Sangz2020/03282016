package esi.automation.home.parser;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.apache.log4j.Logger;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.MainframeTestStep;
import esi.automation.home.model.Step;
import esi.automation.home.model.WebStep;
import esi.automation.home.model.WebSteps;

public class Parser {

    private List<Step> testSteps = new ArrayList<Step>();
    private MainframeTestStep testStep = null;
    private MainframeTestCase testCase = null;
    

    private final String WEB_STEPS[] = {"SWITCHTOWINDOW", "DOASSERT", "INPUT", "NAVIGATE", "CLICK", "ALERT", "SELECT", "SLEEP" ,"GETVALUE", "SELECTJS", "CLICKJS"};

    static Logger log = Logger.getLogger(Parser.class);

    private JSONArray setJsonElementTestCase(JSONObject jsonObject) throws Exception {

        testCase = new MainframeTestCase();

        JSONObject jsonChildObject = (JSONObject) jsonObject.get("testCase");

        String jsonChildName = (String) jsonChildObject.get("name");
        String jsonChildCurator = (String) jsonChildObject.get("curator");

        JSONObject jsonChildObjectConfiguration = (JSONObject) jsonChildObject.get("configuration");
        String jsonStringScreenshot = (String) jsonChildObjectConfiguration.get("screenshots");
        String host = (String) jsonChildObjectConfiguration.get("host");
        String port = (String) jsonChildObjectConfiguration.get("port");

        testCase.setCurator(jsonChildCurator);
        testCase.setName(jsonChildName);
        testCase.setScreenshot(jsonStringScreenshot);
        testCase.setHost(host);
        testCase.setPort(port);

        JSONArray jsonArrayTestSteps = (JSONArray) jsonChildObject.get("testSteps");
        return jsonArrayTestSteps;
    }

    public MainframeTestCase parse(JSONObject jsonObject) throws Exception {

        JSONArray jsonArray = setJsonElementTestCase(jsonObject);
        return setJsonElementTestSteps(jsonArray);
    }

    public MainframeTestCase parse(File jsonFile) throws Exception {

        JSONParser jsonParser = new JSONParser();
        Object obj = jsonParser.parse(new FileReader(jsonFile));
        JSONObject jsonObject = (JSONObject) obj;
        JSONArray jsonArrayTestSteps = setJsonElementTestCase(jsonObject);

        return setJsonElementTestSteps(jsonArrayTestSteps);
    }

    public MainframeTestCase setJsonElementTestSteps(JSONArray jsonArray) throws Exception {

        for (Object obj : jsonArray) {
            JSONObject jsonObj = (JSONObject) obj;
            if (null != jsonObj) {

                for (Object key : jsonObj.keySet()) {
                    String jsonTestStepKey = (String) key;
                    if (isWebStep(jsonTestStepKey, jsonObj)) {
                        WebStep webStep = new WebStep();
                        JSONObject webStepJsonObj = (JSONObject) jsonObj.get(jsonTestStepKey);
                        webStep = getWebStepFromJsonObj(jsonTestStepKey, webStepJsonObj);
                        testSteps.add(webStep);
                    } else {
                        testStep = new MainframeTestStep();
                        testStep.setStepName(jsonTestStepKey);
                        JSONObject testStepObj = (JSONObject) jsonObj.get(jsonTestStepKey);
                        testStep.setRow((Long) testStepObj.get("row"));
                        testStep.setColumn((Long) testStepObj.get("column"));
                        testStep.setValue((String) testStepObj.get("value"));
                        testStep.setKeyname((String) testStepObj.get("keyname"));
                        testStep.setLabel((String) testStepObj.get("label"));
                        testStep.setTimeInMillis((Long) testStepObj.get("timeInMillis"));
                        testStep.setLabelPosition((String) testStepObj.get("position"));
                        testStep.setField_no((Long) testStepObj.get("field"));
                        testStep.setOffset((Long) testStepObj.get("offset"));
                        testStep.setLength((Long) testStepObj.get("length"));
                        testStep.setOperator((String) testStepObj.get("operator"));
                        if (testStep.getStepName().equalsIgnoreCase("wait")) {
                            if (testStep.getRow() != null && testStep.getColumn() != null
                                    && testStep.getValue() != null && testStep.getTimeInMillis() != null) {
                                testStep.setType(Keywords.TEST_STEP_WAIT_FOR_CORDINATE);
                            } else if (testStep.getTimeInMillis() != null && null == testStep.getRow()) {
                                testStep.setType(Keywords.TEST_STEP_WAIT_FOR_TIME);
                            }
                        } else if (testStep.getStepName().equalsIgnoreCase("input")) {
                            if (null != testStep.getOffset() && null != testStep.getField_no()
                                    && null != testStep.getLength()) {
                                testStep.setType(Keywords.TEST_STEP_WRITE_AT_FIELD);
                            } else if (null == testStep.getLabel() && null == testStep.getKeyname()) {
                                testStep.setType(Keywords.TEST_STEP_WRITE_AT_CORDINATE);
                            } else if (null != testStep.getKeyname()) {
                                testStep.setType(Keywords.TEST_STEP_SEND_KEY_NAME);
                            } else if (null == testStep.getKeyname() && null != testStep.getLabel()
                                    && null != testStep.getValue()) {
                                if (null == testStep.getLabelPosition())
                                    throw new Exception("Label position should be defined : " + testStep.getValue());
                                testStep.setType(Keywords.TEST_STEP_WRITE_AT_LABEL);
                            } else {
                                throw new Exception("Error : Configuration has gone wrong with this step - "
                                        + testStep.toString());
                            }
                        } else if (testStep.getStepName().equalsIgnoreCase("readValue")) {
                            if (testStep.getField_no() != null && testStep.getValue() != null) {
                                testStep.setType(Keywords.TEST_STEP_READ_AT_FIELDNUMBER);

                            } else if (null == testStep.getLabel() && null == testStep.getKeyname()) {
                                testStep.setType(Keywords.TEST_STEP_READ_AT_CORDINATE);

                            } else if (testStep.getLabel() != null && testStep.getLabelPosition() != null
                                    && testStep.getValue() != null) {
                                testStep.setType(Keywords.TEST_STEP_READ_AT_LABEL);
                            } else {
                                throw new Exception("Error : Configuration has gone wrong with this step - "
                                        + testStep.toString());
                            }
                        } else if (testStep.getStepName().equalsIgnoreCase("assert")) {
                        	if (testStep.getField_no() != null && testStep.getValue() != null) {
                                testStep.setType(Keywords.TEST_STEP_ASSERT_AT_FIELDNUMBER);
                            } else if (testStep.getRow() != null && testStep.getColumn() != null
                                    && testStep.getValue() != null) {
                                testStep.setType(Keywords.TEST_STEP_ASSERT_AT_CORDINATE);
                            }else if (testStep.getLabel() != null && testStep.getLabelPosition() != null
                                    && testStep.getValue() != null) {
                                testStep.setType(Keywords.TEST_STEP_ASSERT_AT_LABEL);
                            } else {
                                throw new Exception("Error : Configuration has gone wrong with this step - "
                                        + testStep.toString());
                            }
                        }

                        testSteps.add(testStep);
                    }
                }
            }
        }

        testCase.setTestSteps(testSteps);
        return testCase;
    }

    private WebStep getWebStepFromJsonObj(String key, JSONObject webStepJsonObj) {

        WebSteps websteps = new WebSteps();
        WebStep webStep = null;
        webStep = new WebStep();
        if (key.equals("navigate")) {
            // webStep.setWebUrl((String)webStepJsonObj.get(key));
            String url = (String) webStepJsonObj.get("url");
            String browser = (String) webStepJsonObj.get("browser");
            webStep.setBrowser(browser);
            webStep.setWebUrl(url);
            webStep.setWebStepName("navigate");

        } else if (key.equals("input")) {
            String switchToFrame = (String) webStepJsonObj.get("switchToFrame");
            String selectBy = (String) webStepJsonObj.get("selectBy");
            String elementId = (String) webStepJsonObj.get("elementID");
            String inputValue = (String) webStepJsonObj.get("value");
            webStep.setWebStepName("input");
            webStep.setSwitchToFrame(switchToFrame);
            webStep.setElementID(elementId);
            webStep.setSelectBy(selectBy);
            webStep.setValue(inputValue);

        } else if (key.equals("click")) {
            String selectBy = (String) webStepJsonObj.get("selectBy");
            String elementId = (String) webStepJsonObj.get("elementID");
            webStep.setWebStepName("click");
            webStep.setElementID(elementId);
            webStep.setSelectBy(selectBy);

        } else if (key.equals("Select")) {
        	String switchToFrame = (String) webStepJsonObj.get("switchToFrame");
            String selectBy = (String) webStepJsonObj.get("selectBy");
            String elementId = (String) webStepJsonObj.get("elementID");
            String inputValue = (String) webStepJsonObj.get("value");
            webStep.setWebStepName("Select");
            webStep.setSwitchToFrame(switchToFrame);
            webStep.setElementID(elementId);
            webStep.setSelectBy(selectBy);
            webStep.setValue(inputValue);
            
        } else if (key.equals("SelectJS")) {
        		//String switchToFrame = (String) webStepJsonObj.get("switchToFrame");
                String selectBy = (String) webStepJsonObj.get("selectBy");
                String elementId = (String) webStepJsonObj.get("elementID");
                String inputValue = (String) webStepJsonObj.get("value");
                webStep.setWebStepName("SelectJS");
                //webStep.setSwitchToFrame(switchToFrame);
                webStep.setElementID(elementId);
                webStep.setSelectBy(selectBy);
                webStep.setValue(inputValue);

        } else if (key.equals("waitForElement")) {
            String selectBy = (String) webStepJsonObj.get("selectBy");
            String elementId = (String) webStepJsonObj.get("elementID");
            webStep.setWebStepName("waitForElement");
            webStep.setElementID(elementId);
            webStep.setSelectBy(selectBy);
            
        } else if (key.equals("Sleep")) {
            String milisec = (String) webStepJsonObj.get("milisec");
            webStep.setWebStepName("Sleep");
            webStep.setMilisec(milisec);

        } else if (key.equals("clickJS")) {
            String selectBy = (String) webStepJsonObj.get("selectBy");
            String elementId = (String) webStepJsonObj.get("elementID");
            webStep.setWebStepName("clickJS");
            webStep.setElementID(elementId);
            webStep.setSelectBy(selectBy);

        } else if (key.equals("alert")) {
            String alert = (String) webStepJsonObj.get("alertv");
            webStep.setWebStepName("alert");
            webStep.setAlertv(alert);
            
        } else if (key.equals("getValue")) {
        	String switchToFrame = (String) webStepJsonObj.get("switchToFrame");
        	String selectBy = (String) webStepJsonObj.get("selectBy");
            String elementId = (String) webStepJsonObj.get("elementID");
            String inputValue = (String) webStepJsonObj.get("value");
            webStep.setWebStepName("getValue");
            webStep.setSwitchToFrame(switchToFrame);
            webStep.setElementID(elementId);
            webStep.setSelectBy(selectBy);
            webStep.setValue(inputValue);
            
        } else if (key.equals("doAssert")) {
        	String selectBy = (String) webStepJsonObj.get("selectBy");
            String elementId = (String) webStepJsonObj.get("elementID");
            String inputValue = (String) webStepJsonObj.get("value");
            webStep.setWebStepName("doAssert");
            webStep.setElementID(elementId);
            webStep.setSelectBy(selectBy);
            webStep.setValue(inputValue);
            
        }	else if (key.equals("switchToWindow")) {
        	String switchToWindow = (String) webStepJsonObj.get("switchToWin");
            webStep.setWebStepName("switchToWindow");
            webStep.setSwitchToWin(switchToWindow);
        }

        return webStep;
    }

    private boolean isWebStep(String key, JSONObject stepObj) {

        boolean isWebStep = false;
        if (Arrays.asList(WEB_STEPS).contains(key.toUpperCase())) {
            isWebStep = true;
            if (key.equalsIgnoreCase("input") || key.equalsIgnoreCase("getValue") || key.equalsIgnoreCase("doAssert")) {
                JSONObject testStepObj = (JSONObject) stepObj.get(key);
                String selectBy = (String) testStepObj.get("selectBy");
                String elementID = (String) testStepObj.get("elementID");
                String value = (String) testStepObj.get("value");
                if (null != selectBy && null != elementID && null != value) {
                    isWebStep = true;
                } else {
                    isWebStep = false;
                }
            }
        }
        return isWebStep;
    }

}
