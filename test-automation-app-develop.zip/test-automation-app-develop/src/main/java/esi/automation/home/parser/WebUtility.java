package esi.automation.home.parser;

import java.io.IOException;
import java.util.Iterator;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class WebUtility

{

    public static WebDriver driver;
    public static String strException;
    static String driverPath;
 
    public static WebDriver Launch(String BrowserName, String url) {
    			
    	        try {
    	            switch (BrowserName.toLowerCase()) {
    	                case "chrome": {
    	                	WebUtility.driver = Navigate.getChromeBrowser();
    	                    break;
    	                }
    	                case "firefox": {
    	                	WebUtility.driver = Navigate.getffBrowser();
    	                	break;
    	                }
    	                case "headless": {
    	                	WebUtility.driver = new HtmlUnitDriver();
    	                    break;
    	                }
    	                case "ie": {
    	                	WebUtility.driver = Navigate.getIEBrowser();
    	                    break;
    	                }
    	                case "ie_saucelabs": {
    	                	WebUtility.driver = Navigate.getIEBrowserSaucelabs();
    	                    break;
    	                }
    	            }
    	            
    	           
    	            WebUtility.driver.get(url);
    	           
    	            WebUtility.driver.manage().timeouts().implicitlyWait(1000, TimeUnit.MILLISECONDS);
    	            Executer.log.info("Loaded on the Browser " +BrowserName+ " With URL : "+url);  
    	        } catch (Exception ex) {
    	        	Executer.log.error(ex);
    	        	
    	        }
    	        return WebUtility.driver;
    	    }
    
    
    
    public static boolean WaitForElement(final String jsonLocator, final String jsonLocValue, final int FinaSync) {

        final WebDriverWait wait = new WebDriverWait(WebUtility.driver, FinaSync);
        boolean blnWaitForElementExist = false;
        try {
        	Thread.sleep(10000);
        wait.until(ExpectedConditions.visibilityOfElementLocated(WebUtility.ElementLocator(jsonLocator, jsonLocValue)));
        blnWaitForElementExist = true;
        }catch (Exception e) {
        	Executer.log.error(e);
            blnWaitForElementExist = false;
        } 
            return blnWaitForElementExist;
        }

    public static void highLighter(WebElement element){
    	final JavascriptExecutor jse = (JavascriptExecutor) WebUtility.driver;
        jse.executeScript("arguments[0].scrollIntoView(true);", element);
        jse.executeScript("arguments[0].style.border='2px solid red'", element);
    }
    
    public static By ElementLocator(String JsonLocator, String jsonLocValue){
    	By by = null;
    	
    	switch(JsonLocator.toLowerCase()){
    	case "id" :{
    		by = By.id(jsonLocValue);
    		break;
    	}
    	case "xpath" : {
    		by = By.xpath(jsonLocValue);
    		break;
    	}
    	case "css" :{
    		by = By.cssSelector(jsonLocValue);
    		break;
    	}
    	case "name" :{
    		by = By.name(jsonLocValue);
    		break;
    	}
    	case "link" :{
    		by = By.linkText(jsonLocValue);
    		break;
    	}
	}
       	return by;
    } 
    
    
    public static WebElement Element(String JsonLocator, String jsonLocValue ){
       	WebElement element = WebUtility.driver.findElement(WebUtility.ElementLocator(JsonLocator, jsonLocValue));
		return element;
    
    }
    public static List<WebElement> Elements(String JsonLocator, String jsonLocValue){
       	List<WebElement> element = WebUtility.driver.findElements(WebUtility.ElementLocator(JsonLocator, jsonLocValue));
		return element;
     }
    
   public static boolean ObjectExists(String JsonLocator, String jsonLocValue,
            String strHighLight, int FinaSync) {
	   
	   try {
		Thread.sleep(5000);
	} catch (InterruptedException e1) {
		
		e1.printStackTrace();
	}
        boolean blnStatus = false;
        WebElement element_node = null;
        boolean blnDisplayed = false;
        WaitForElement(JsonLocator, jsonLocValue, FinaSync);
        
        try {
            blnDisplayed = WebUtility.Element(JsonLocator,jsonLocValue).isDisplayed();
            if (blnDisplayed) {
                element_node = WebUtility.Element(JsonLocator,jsonLocValue);
                WebUtility.Element(JsonLocator,jsonLocValue);
                blnStatus = true;
            }
        } catch (NoSuchElementException e) {
        	Executer.log.error(e);
            
            blnStatus = false;
        }
        
        if (strHighLight.equals("Yes"))
            highLighter(element_node);
     
      return blnStatus;
    }

   public static void ClickAt(String jsonLocator, String jsonLocValue) throws Exception {
        int millisecond = 1000;
       WebElement target = WebUtility.Element(jsonLocator, jsonLocValue);
       highLighter(target);
       ((JavascriptExecutor) WebUtility.driver).executeScript("arguments[0].scrollIntoView(true);", target);
       Thread.sleep(millisecond);
        target.click();

    }

    public static void ClickJS(String jsonLocator, String jsonLocValue, String strHighLight) {
        final int millisecond = 1000;
        WebElement element = null;
        int ele = WebUtility.Elements(jsonLocator, jsonLocValue).size();
        if (ele == 0){
        	Executer.log.info("element not present");
        }else{
        element = WebUtility.Element(jsonLocator, jsonLocValue);
        ((JavascriptExecutor) WebUtility.driver).executeScript("arguments[0].scrollIntoView(true);", element);
        ((JavascriptExecutor) WebUtility.driver).executeScript("arguments[0].click();", element);
        try {Thread.sleep(millisecond);} catch (Exception e) {}
        if (strHighLight.equalsIgnoreCase("Yes"))
        	highLighter(element);
        }
    }
    
   
    public static void SelectJS(String jsonLocator, String jsonLocValue, String strHighLight) {
    	final int millisecond = 1000;
        WebElement element = null;
        int ele = WebUtility.Elements(jsonLocator, jsonLocValue).size();
        if (ele == 0){
        	Executer.log.info("element not present");
        }else{
        element = WebUtility.Element(jsonLocator, jsonLocValue);
        ((JavascriptExecutor) WebUtility.driver).executeScript("arguments[0].scrollIntoView(true);", element);
        ((JavascriptExecutor) WebUtility.driver).executeScript("arguments[0].click();", element);
        try {Thread.sleep(millisecond);} catch (Exception e) {}
        if (strHighLight.equalsIgnoreCase("Yes"))
        	highLighter(element);
        }
    }

    public static boolean Click(String jsonLocator, String jsonLocValue, String strHighLight, int FinaSync) {
        boolean blnIsElementExists = false;
        try {
            blnIsElementExists = ObjectExists(jsonLocator, jsonLocValue, strHighLight, FinaSync);
            if (blnIsElementExists){
            	WebUtility.Element(jsonLocator, jsonLocValue).click();
            	Executer.log.info("<<< Click Passed >>> Object "+jsonLocator + " : "+jsonLocValue);
            
        }else{
        	Executer.log.info("<<< Click Failed >>> Object "+jsonLocator + " : "+jsonLocValue);
        }
        
            } catch (Exception ex) {
            	Executer.log.error(ex);
        }
        return blnIsElementExists;
    }

    public static void alert(String value) {

        if (value.equalsIgnoreCase("Ok")) {
            WebDriverWait wait = new WebDriverWait(WebUtility.driver, 15, 100);
            wait.until(ExpectedConditions.alertIsPresent());
            Alert al = WebUtility.driver.switchTo().alert();
            al.accept();
            Executer.log.info("<<< Clicked on Alert OK >>>");
            
        } else if (value.equalsIgnoreCase("Cancel")) {
            WebDriverWait wait = new WebDriverWait(WebUtility.driver, 15, 100);
            wait.until(ExpectedConditions.alertIsPresent());
            Alert al = WebUtility.driver.switchTo().alert();
            al.dismiss();
            Executer.log.info("<<< Clicked on Alert OK >>>");
        }
    }

    public static void switchToFrame(String frameName) {

        WebUtility.driver.switchTo().frame(frameName);

    }
    
    public static boolean getValue(String frameName, String jsonLocator, String jsonLocValue, String key, String strHighLight, int FinaSync) {
    	 
    	 boolean blnIsElementExists = false;
    	 String value = null;
    	 //WebUtility.Element(jsonLocator, jsonLocValue).getText();
    	 try{
    		 if (null != frameName && !frameName.isEmpty())
    	            WebUtility.driver.switchTo().frame(frameName);
    		 blnIsElementExists = ObjectExists(jsonLocator, jsonLocValue, strHighLight, FinaSync);
    		 if(blnIsElementExists){
    		 	value = WebUtility.Element(jsonLocator, jsonLocValue).getText();
    		 	if(value.isEmpty() || value.length()==0){
    		 	value = WebUtility.Element(jsonLocator, jsonLocValue).getAttribute("value");
    		 	}
    		 	Executer.log.info("<<< GetValue Operation Passed >>> GetValue key is :"+ key+ " & Value fetched from the application is : "+value);
        		ValuePass.addValue(key, value);
        		
        	} else {
        		Executer.log.info("<<< GetValue Operation Failed >>> GetValue key is :"+ key+ " & Value fetched from the application is : "+value);
        	}
    		 
    	 }catch(Exception ex){
    		 
    	 }
    	 return blnIsElementExists;
    }

    public static boolean Input(String jsonLocator, String jsonLocValue, String Value,
            String strHighLight, int FinaSync, String frameName) {
       if (null != frameName && !frameName.isEmpty())
            WebUtility.driver.switchTo().frame(frameName);
        boolean blnIsElementExists = false;
        try {
            blnIsElementExists = ObjectExists(jsonLocator, jsonLocValue, strHighLight, FinaSync);
            if (blnIsElementExists) {
            	//Executer.log.info("<<< Input Operation Passed >>> Object for "+jsonLocator + " : "+jsonLocValue);
            	WebUtility.Element(jsonLocator, jsonLocValue).clear();
            	
            	if(Value.startsWith("$")){
            		String valueKey = Value.substring(1, Value.length());
            		String dValue = ValuePass.getDynamicValue(valueKey);
            		
            		WebUtility.Element(jsonLocator, jsonLocValue).sendKeys(dValue);
            		Executer.log.info("<<< Input Passed >>> Object for "+jsonLocator + ":"+jsonLocValue +" Value Passed : "+dValue);
            	}else{
            		WebUtility.Element(jsonLocator, jsonLocValue).sendKeys(Value);
            		Executer.log.info("<<< Input Passed >>> Object for "+jsonLocator + ":"+jsonLocValue +" Value Passed : "+Value);
            	}
            	
            	
            }else {
            	Executer.log.info("<<< Input Failed >>> Object for "+jsonLocator + " : "+jsonLocValue);
            }
        } catch (Exception ex) {
        	Executer.log.error(ex);
        }
        
        return blnIsElementExists;
    }

    public static boolean Select(String jsonLocator, final String jsonLocValue, final String Value,
            final String strHighLight, final int FinaSync, String frameName) {
    	
    	if (null != frameName && !frameName.isEmpty())
            WebUtility.driver.switchTo().frame(frameName);

        boolean blnIsElementExists = false;
        try {
            blnIsElementExists = ObjectExists(jsonLocator, jsonLocValue, strHighLight, FinaSync);
            if (blnIsElementExists) {
            	
            	WebElement ele = WebUtility.Element(jsonLocator, jsonLocValue);
                WebDriverWait wait = new WebDriverWait(WebUtility.driver, 10000);
                wait.until(ExpectedConditions.elementToBeClickable(ele));
                ((JavascriptExecutor) WebUtility.driver).executeScript("arguments[0].scrollIntoView(true);", ele);
                Actions mouse = new Actions(WebUtility.driver);
                mouse.moveToElement(ele).click();
                mouse.build();
                mouse.perform();
                new Select(ele).selectByVisibleText(Value);
                Executer.log.info("<<< Select Operation Passed >>> Object "+jsonLocator + " : "+jsonLocValue +": "+Value);
            	
            }
            Executer.log.info("<<< Select Failed >>> Object "+jsonLocator + " : "+jsonLocValue +": "+Value);
            
        } catch (Exception ex) {
        	Executer.log.error(ex);
        }
        return blnIsElementExists;
    }

    
    public static void switchToParentWin(){
    	
    }
    
    
    public static void switchToSubwindow(String switchToWin){
    	String prntWin = WebUtility.driver.getWindowHandle();
    	try{
    	if(switchToWin.equalsIgnoreCase("Yes")){
    	String subWin = null;
    	Set<String> handles = WebUtility.driver.getWindowHandles();
    	
    	Iterator<String> itr = handles.iterator();
    	while(itr.hasNext()){
    		
    		
    		subWin = itr.next();
    		System.out.println(subWin);
    		if(!itr.hasNext()){
    		WebUtility.driver.switchTo().window(subWin);
    		System.out.println(WebUtility.driver.getTitle());
    		System.out.println("switched");
    		}
    		
    	}
    	
    		
    	}else if(switchToWin.equalsIgnoreCase("No")){
    		WebUtility.driver.switchTo().window(prntWin);
    	}
    	}catch(Exception ex){
    		Executer.log.error(ex);
    	}
    	
    }
    
    
   
    
    public static void KillProcess() {

        try {

            Runtime.getRuntime().exec("TASKKILL /F /IM chromedriver.exe");
            Runtime.getRuntime().exec("TASKKILL /F /IM IEDriverServer.exe");
            System.exit(0);

        } catch (IOException ioe) {
            ioe.printStackTrace();
        }

    }

    public static void driverClose() {
    	WebUtility.KillProcess();
        WebUtility.driver.close();
        
        
    }

    public static void Sleep(String value) {
        int result = Integer.parseInt(value);
        try {
            Thread.sleep(result);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    

   
}
