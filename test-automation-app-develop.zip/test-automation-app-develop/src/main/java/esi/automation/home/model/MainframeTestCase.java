/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.model;

import java.util.List;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class MainframeTestCase {

    private String name;
    private String curator;
    private String screenshot;
    private String host;
    private String port;
    private List<Step> testSteps;

    public String getName() {

        return this.name;
    }

    public void setName(String name) {

        this.name = name;
    }

    public String getCurator() {

        return this.curator;
    }

    public void setCurator(String curator) {

        this.curator = curator;
    }

    public String getScreenshot() {

        return this.screenshot;
    }

    public void setScreenshot(String screenshot) {

        this.screenshot = screenshot;
    }

    public String getHost() {

        return this.host;
    }

    public void setHost(String host) {

        this.host = host;
    }

    public String getPort() {

        return this.port;
    }

    public void setPort(String port) {

        this.port = port;
    }

    public List<Step> getTestSteps() {

        return this.testSteps;
    }

    public void setTestSteps(List<Step> testSteps) {

        this.testSteps = testSteps;
    }

}
