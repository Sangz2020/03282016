package esi.automation.home.model;

import esi.automation.home.model.Step;

public class WebStep extends Step {
	private String webStepName = "";
	private String webUrl;
	private String browser;
	private String selectBy;
	private String elementID;
	private String value;
	private String milisec;
	private String switchToFrame;
	private String alertv;
	private String switchToWin;
	//private String key;
	
	
	/*public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}*/
	public String getAlertv() {
		return alertv;
	}
	public void setAlertv(String alertv) {
		this.alertv = alertv;
	}
	
	public String getSwitchToWin() {
		return switchToWin;
	}
	public void setSwitchToWin(String switchToWin) {
		this.switchToWin = switchToWin;
	}
	public String getMilisec() {
		return milisec;
	}
	public void setMilisec(String milisec) {
		this.milisec = milisec;
	}

	
	public String getElementID() {
		return elementID;
	}
	public void setElementID(String elementID) {
		this.elementID = elementID;
	}
	public String getSwitchToFrame() {
		return switchToFrame;
	}
	public void setSwitchToFrame(String switchToFrame) {
		this.switchToFrame = switchToFrame;
	}
	public String getSelectBy() {
		return selectBy;
	}
	
	public void setSelectBy(String selectBy) {
		this.selectBy = selectBy;
	}
	public String getElementName() {
		return elementID;
	}
	public void setElementName(String elementName) {
		this.elementID = elementName;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	private boolean isScreenShotRequired;
	
	public String getWebStepName() {
		return webStepName;
	}
	public void setWebStepName(String webStepName) {
		this.webStepName = webStepName;
	}
	public String getWebUrl() {
		return webUrl;
	}
	public void setWebUrl(String webUrl) {
		this.webUrl = webUrl;
	}
	public String getBrowser() {
		return browser;
	}
	public void setBrowser(String browser) {
		this.browser = browser;
	}
	public boolean isScreenShotRequired() {
		return isScreenShotRequired;
	}
	public void setScreenShotRequired(boolean isScreenShotRequired) {
		this.isScreenShotRequired = isScreenShotRequired;
	}
	
	
	
}
