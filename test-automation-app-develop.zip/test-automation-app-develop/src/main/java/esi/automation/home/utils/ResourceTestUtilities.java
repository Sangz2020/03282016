package esi.automation.home.utils;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.stream.Collectors;

public class ResourceTestUtilities {

    public static String readResource(String pathToResource) {

        InputStream stream = ResourceTestUtilities.class.getClassLoader().getResourceAsStream(pathToResource);

        String resourceString = null;
        try (BufferedReader buffer = new BufferedReader(new InputStreamReader(stream))) {
            resourceString = buffer.lines().collect(Collectors.joining(""));
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                stream.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        return resourceString;
    }
}
