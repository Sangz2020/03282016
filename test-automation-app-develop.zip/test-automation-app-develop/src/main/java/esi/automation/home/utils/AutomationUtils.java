/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.utils;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.jagacy.Field;
import com.jagacy.util.JagacyException;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class AutomationUtils {

    public static String getCurrentDateTime() {

        final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String currentDateTime = dateFormat.format(new Date());
        return currentDateTime;
    }

    public static String getCurrentDateTimeHrsMillSec() {

        final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss:sss");
        String currentDateTime = dateFormat.format(new Date());
        return currentDateTime;
    }

    public static void readScreenData(String[] readScreenData) throws JagacyException {

        System.out.println(" *********** Begin Printing Screen Data ************** ");
        int count = 0;
        for (String currentField : readScreenData) {

            System.out.println("Row Number : " + count + " : " + currentField.toString());
            count += 1;
        }
        System.out.println(" *********** End Printing Screen Data ************** ");

    }

    public static void readFieldData(Field[] allFields) throws JagacyException {

        System.out.println(" *********** Begin Printing Field Data ************** ");
        System.out.println("Total fields count - " + allFields.length);
        for (Field currentField : allFields) {
            System.out.println("RowNumber : " + currentField.getRow() + "--\n" + "Column Number : "
                    + currentField.getColumn() + "\n" + "FieldNumber : " + currentField.getFieldNumber() + "\n"
                    + "Field Value : " + currentField.getValue() + "\n" + "Field isModified : "
                    + currentField.isModified() + "\n" + "Field isNumeric : " + currentField.isNumeric() + "\n"
                    + "Field isProtected : " + currentField.isProtected() + "\n");
        }
        System.out.println(" *********** End Printing Field Data ************** ");

    }

    public static String readFieldDataByRowColumn(Field[] allFields, Long row, Long column) throws JagacyException {

        String data = null;
        for (Field currentField : allFields) {
            if (currentField.getColumn() == column && currentField.getRow() == row) {
                data = currentField.getValue();
                break;
            }
        }
        return data;
    }

    public static String readFieldDataByFieldNumber(Field[] allFields, Long fieldNumber) throws JagacyException {

        String data = null;
        for (Field currentField : allFields) {
            if (currentField.getFieldNumber() == fieldNumber) {
                data = currentField.getValue();
                break;
            }
        }
        return data;
    }

    public static int readFieldNumberByLabel(Field[] allFields, String label) throws JagacyException {

        int fieldNumber = 0;
        for (Field currentField : allFields) {
            if (currentField.getValue().toUpperCase().trim().contains(label.toUpperCase().trim())) {
                fieldNumber = currentField.getFieldNumber();
                break;
            }
        }
        return fieldNumber;
    }
}
