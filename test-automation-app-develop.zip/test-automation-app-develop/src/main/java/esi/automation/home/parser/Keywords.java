package esi.automation.home.parser;

public final class Keywords {

    public static final String GO_TO = "go to";
    public static final String GIVEN = "Given";
    public static final String WHEN = "When";
    public static final String THEN = "Then";
    public static final String AND = "And";
    public static final String WHITE_SPACE = " ";

    public static final String PARAM_TYPE_STRING = "String";
    public static final String ACCESS_TYPE_PRIVATE = "private";

    public static final String WHEN_THE_USER_CLICK_ON = "the_user_click_on";
    public static final String WHEN_I_CLICK_ON = "i_click_on";

    public static final String I_GO_TO = "i_go_to";
    public static final String USER_GO_TO = "the_user_go_to";
    public static final String USER_IS_ON_THE = "the_user_is_on_the";

    public static final String USER_IS_SHOWN = "the_user_is_shown";
    public static final String SCENARIO_COMPLETE = "scenario_complete";
    public static final String USER_HAS_SET_PREFERENCE = "the_user_has_set_preference";
    public static final String TEXT_SHOULD_BE_CHANGED_TO = "text_should_be_changed_to";

    public static final String ISSUE_NO = "ISSUE_NO";
    public static final String JIRA_USER_NAME = "JIRA_USER_NAME";
    public static final String JIRA_PASSWORD = "JIRA_PASSWORD";
    public static final String JIRA_AUTH_URL = "JIRA_AUTH_URL";
    public static final String FEATURE_FILE = "FEATURE_FILE";
    public static final String TOKEN_SPLIT_CHAR = "TOKEN_SPLIT_CHAR";
    public static final String TEST_CLASS_FILE = "TEST_CLASS_FILE";
    public static final String CLASS_OUTPUT_FOLDER = "CLASS_OUTPUT_FOLDER";

    public static final String TEST_STEP_WRITE_AT_CORDINATE = "WRITE_AT_CORDINATE";
    public static final String TEST_STEP_WRITE_AT_LABEL = "WRITE_AT_LABEL";
    public static final String TEST_STEP_WRITE_AT_FIELD = "WRITE_AT_FIELD";

    public static final String TEST_STEP_READ_AT_CORDINATE = "READ_AT_CORDINATE";
    public static final String TEST_STEP_READ_AT_FIELDNUMBER = "READ_AT_FIELDNUMBER";
    public static final String TEST_STEP_READ_AT_LABEL = "READ_AT_LABEL";
    public static final String TEST_STEP_ASSERT_AT_CORDINATE = "ASSERT_AT_CORDINATE";
    public static final String TEST_STEP_ASSERT_AT_FIELDNUMBER = "ASSERT_AT_FIELDNUMBER";
    public static final String TEST_STEP_ASSERT_AT_LABEL = "ASSERT_AT_LABEL";

    public static final String TEST_STEP_WAIT_FOR_CORDINATE = "WAIT_FOR_CORDINATE";
    public static final String TEST_STEP_WAIT_FOR_TIME = "WAIT_FOR_TIME";
    public static final String TEST_STEP_SEND_KEY_NAME = "SEND_KEY_NAME";

}
