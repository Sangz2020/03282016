package esi.automation.home.parser;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Properties;

public class ValuePass {
	
	static File file =null;
	 static FileOutputStream out = null;
	 static FileInputStream in = null;
	 static Properties pp = new Properties();
   static {
       
   	try {
   		file = new File("src/main/resources/valuePair.properties");
   		if(file.exists()){
   			in = new FileInputStream(file);
   		}else{
   			file.createNewFile();
   			in = new FileInputStream(file);
   			}
		} catch (Exception e) {
			e.printStackTrace();
		}
   }
   
   public static void addValue(String key,String value) throws Exception{
	   pp.load(in);
	   out = new FileOutputStream(file);
	   pp.setProperty(key, value);
	   pp.store(out, "");
   }
   
   public static String getDynamicValue(String key){
	   String value = pp.get(key).toString();
	   
	   return value;
   }
   

}
