package esi.automation.home.parser;

import static org.junit.Assert.*;

import java.io.IOException;

import javax.swing.text.Highlighter;

import org.junit.Assert;
import org.junit.Test;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class Asserts {

    public static boolean doAssert(String jsonLocator, String jsonLocValue, String Value,
            String strHighLight, int FinaSync) {

        final StringBuffer verificationErrors = new StringBuffer();
        boolean blnIsElementExists = false;
        boolean blnStatusText = false;
        String strAssert = null;
        try{
        blnIsElementExists = WebUtility.ObjectExists(jsonLocator, jsonLocValue, strHighLight, FinaSync);
        if (blnIsElementExists) {
        	strAssert = WebUtility.Element(jsonLocator, jsonLocValue).getText();
		 	if(strAssert.isEmpty() || strAssert.length()==0){
		 		strAssert = WebUtility.Element(jsonLocator, jsonLocValue).getAttribute("value");
		 	}
		 	
		 	if(Value.startsWith("$")){
        		String val = Value.substring(1, Value.length());
        		String dValue = ValuePass.getDynamicValue(val);
        		Assert.assertEquals(strAssert, dValue);
        		Executer.log.info("<<< Assert Passed >>> The value supplied as : "+dValue +" & The element got is :"+strAssert);
        		
        	}else{
        		Assert.assertEquals(strAssert, Value);
        		Executer.log.info("<<< Assert Passed >>> The value supplied as : "+Value +" & The element got is :"+strAssert);
        		
        	}
		 	
                    
        }
        } catch (Error e) {
        	//e.printStackTrace();
        	Executer.log.info("<<< Assert Failed >>> The value supplied as : "+Value +" & The element got is :"+strAssert);
        	Executer.log.error(e);
        	verificationErrors.append(e.toString());
        	blnStatusText = false;
        }
        
             
        //System.out.println("text matched >>>: " + blnStatusText);
        return blnStatusText;
    }

    

}

