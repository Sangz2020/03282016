package esi.automation.home.mainframe;

import java.io.File;

import org.apache.log4j.Logger;

import esi.automation.home.model.ResponseResult;
import esi.automation.home.parser.Executer;
import esi.automation.home.parser.Parser;

public class MainframeClientLocalUsingJSON {

    static Logger log = Logger.getLogger(MainframeClientLocalUsingJSON.class);

    public ResponseResult readAndExecuteSteps(String fileName) throws Exception {

        ResponseResult responseResult = null;

        Executer executor = null;
        try {
            ClassLoader classLoader = getClass().getClassLoader();
            File file = new File(classLoader.getResource(fileName).getFile());

            Parser parser = new Parser();
            executor = Executer.getInstance(parser.parse(file));
            responseResult = executor.execute();
            // log.info("Data Processing completed." + responseResultList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return responseResult;
    }
}