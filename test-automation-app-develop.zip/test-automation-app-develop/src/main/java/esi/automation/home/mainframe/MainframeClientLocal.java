package esi.automation.home.mainframe;

import java.awt.AWTException;
import java.awt.HeadlessException;
import java.awt.Rectangle;
import java.awt.Robot;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Enumeration;
import java.util.ResourceBundle;

import javax.imageio.ImageIO;

import org.apache.log4j.Logger;

import com.jagacy.Key;
import com.jagacy.Session3270;
import com.jagacy.util.JagacyException;
import com.jagacy.util.JagacyProperties;

public class MainframeClientLocal extends Session3270 {

    static Logger filelogger = Logger.getLogger("reportsLogger");
    // static Logger log = Logger.getLogger("reportsLogger");

    private JagacyProperties props;
    ResourceBundle configuration = null;
    String userid = "ec4848";
    String password = "Sonu2099";

    public MainframeClientLocal() throws JagacyException, IOException {

        super("example - MainframeClient");

        props = getProperties();
        loadProps();
        Enumeration e = configuration.getKeys();
        while (e.hasMoreElements()) {
            String key = (String) e.nextElement();
            String value = configuration.getString(key);
            props.set(key, value);
        }

    }

    @Override
    protected boolean logon() throws JagacyException {

        filelogger.info("********** Begin  -- Processing Mainframe Data ********** ");

        filelogger.info("...Execution Started...");
        long startTime = System.nanoTime();
        waitForPosition("logon.wait", "logon.timeout.seconds");
        filelogger.info("Connected to mfs");

        writePosition("logon.entry", "b");
        writeKey(Key.ENTER);
        waitForPosition("main.wait", "main.timeout.seconds");

        writeAfterLabel("Userid", userid);
        writeAfterLabel("Password", password);
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        filelogger.info("Sign in process has completed succesfully");

        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        writeKey(Key.ENTER);
        waitForPosition("region.entry", "main.timeout.seconds");

        writePosition("region.entry", "S1MEDA1");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");

        writeAfterLabel("USER-ID", userid);
        writeAfterLabel("PASSWORD", password);
        writePosition("pharmacynumber.entry", "03");
        writeAfterLabel("NEXT SCREEN", "men70");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");

        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        filelogger.info("Login for S1MEDA1 region has completed");

        writeAfterLabel("NEXT SCREEN", "newrx");
        writeAfterLabel("CUST", "396177040794");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");

        waitForPosition("newrxpatient.entry", "main.timeout.seconds");
        writePosition("newrxpatient.entry", "01");

        waitForPosition("newrxdoctorselect.entry", "main.timeout.seconds");
        writePosition("newrxdoctorselect.entry", "x");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");

        writeAfterLabel("REC-DT", "011217");
        writeAfterLabel("ISS-DT", "011217");
        writeAfterLabel("PAYMENT-REC", "10");
        writeAfterLabel("LAST-RX-IN-PAN", "y");
        writeAfterLabel("TYPE", "CA");
        try {
            grabScreenshot("newrx");
        } catch (Exception e1) {
        }
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");

        try {
            grabScreenshot("newrx_verification");
        } catch (Exception e1) {
        }

        writeAfterLabel("# Rxs in Order", "1");
        writeAfterLabel("Is The Above Address Information Correct?", "y");
        writeAfterLabel("Is The Above Payment Information Correct?", "y");
        writeAfterLabel("End of Order", "y");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        filelogger.info("Nrx new order created ");

        writeAfterLabel("Next Screen", "prrsl");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        filelogger.info("Entered into prrsl screen");

        try {
            grabScreenshot("prrsl");
        } catch (Exception e1) {
        }
        String s = "";
        try {
            s = readField("rxno");
        } catch (Exception e) {
            e.printStackTrace();
        }
        try {
            s += " " + readField("rxlocationno");
        } catch (Exception e) {
            e.printStackTrace();
        }
        String rxNumber = s;

        s += " DRUG NOT FOUND";

        writeBeforeLabel(s, "c");
        writeAfterLabel("WORK AREA", "OC");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");

        try {
            grabScreenshot("drug_entry");
        } catch (Exception e1) {
        }
        writeAfterLabel("DRUG NAME", "ATENOLOL PWD 25GM");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");

        writeBeforeLabel("ATENOLOL PWD 25GM", "x");
        writeKey(Key.PF5);
        waitForChange("result.timeout.seconds");

        try {
            grabScreenshot("quick_sig");
        } catch (Exception e1) {
        }
        writeAfterLabel("QUICK SIG", "01");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");

        try {
            grabScreenshot("verify_popup");
        } catch (Exception e1) {
        }

        filelogger.info("enetering verification");
        writeField("verify", "p");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        filelogger.info("drug selection has completed");

        try {
            grabScreenshot("rxchg");
        } catch (Exception e1) {
        }

        writeAfterLabel("Orig-qty", "30  ");

        writeAfterLabel("Act-qty", "30  ");

        writeAfterLabel("DaySply", "30 ");

        writeAfterLabel("Orig-rfls", "3  ");

        writeAfterLabel("Act-rfls", "3  ");

        writeAfterLabel("Md Daw", "n");

        try {
            grabScreenshot("rxchg");
        } catch (Exception e1) {
        }
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        filelogger.info("Entering drug quantity information completed");

        try {
            s = readField("acptcode");
        } catch (Exception e) {
            e.printStackTrace();
        }

        writeAfterLabel("RX ACCEPT", s);

        try {
            grabScreenshot("acceptance_code");
        } catch (Exception e1) {
        }
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");

        filelogger.info("Drug entry has completed");

        writeAfterLabel("NEXT SCREEN", "sgoff");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");
        writeAfterLabel("IF YOU WANT TO SIGN OFF  ENTER \"N\" HERE", "n");
        writeKey(Key.ENTER);
        waitForChange("result.timeout.seconds");

        long endTime = System.nanoTime();
        long totalTimeTakeninnanoseconds = endTime - startTime;
        long totalTimeTakenInMilliseconds = totalTimeTakeninnanoseconds / 1000000;
        long totalTimeTakenInSeconds = totalTimeTakenInMilliseconds / 1000;

        filelogger.info("....Signed off....");
        filelogger.info("....Testcase flow execution has completed....");
        filelogger.info("Total time taken for execution - " + totalTimeTakenInSeconds + " seconds");

        filelogger.info("Execution completed, Nrx new order created -- " + rxNumber);

        filelogger.info("********** End    -- Processing Mainframe Data ********** ");

        return true;
    }

    @Override
    protected void logoff() throws JagacyException {

        // logoff code
    }

    public void loadProps() throws IOException {

        configuration = ResourceBundle.getBundle("fixtures/jagacy/properties/jagacyLocal");
    }

    public void grabScreenshot(String name) throws HeadlessException, AWTException, IOException {

        BufferedImage image = new Robot()
                .createScreenCapture(new Rectangle(Toolkit.getDefaultToolkit().getScreenSize()));
        ImageIO.write(image, "png", new File("C:/esi/screens/" + name + "_screenshot.png"));
    }
}
