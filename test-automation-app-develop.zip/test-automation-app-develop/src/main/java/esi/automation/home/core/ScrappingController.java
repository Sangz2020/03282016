/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.core;

/**
 * @AuthorName  : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
import java.net.URISyntaxException;

import javax.annotation.PostConstruct;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import esi.automation.home.mainframe.MainframeClientFieldLocal;
import esi.automation.home.mainframe.MainframeClientFieldPCF;
import esi.automation.home.mainframe.MainframeClientLocal;
import esi.automation.home.mainframe.MainframeClientLocalUsingJSON;
import esi.automation.home.mainframe.MainframeClientPCF;

@Controller
public class ScrappingController {

    static Logger log = Logger.getLogger(ScrappingController.class);

    @PostConstruct
    public void init() throws URISyntaxException {

        ClassLoader classLoader = getClass().getClassLoader();
        PropertyConfigurator.configure(classLoader.getResource("log4j.properties").getFile());
    }

    @RequestMapping("/scrapetest")
    public @ResponseBody String scrapetest() {

        return "Hello world, Scraping test app!";
    }

    @RequestMapping("/scrapedatalocal")
    public @ResponseBody String scrapeDataLocal() throws Exception {

        String processResult;
        try {
            log.info("********** Begin  -- Processing Mainframe Data ********** ");

            MainframeClientLocal mainframeClient = new MainframeClientLocal();
            mainframeClient.open();
            mainframeClient.close();
            processResult = "Scrape Processing completed locally!";

            log.info("********** End    -- Processing Mainframe Data ********** ");
        } catch (Exception e) {
            processResult = "Error Processing -- " + e.getLocalizedMessage();
            log.info("********** End    -- Processing Mainframe Data ********** ");
        }
        return processResult;
    }

    @RequestMapping("/scrapedatapcf")
    public @ResponseBody String scrapeDataPCF() throws Exception {

        String processResult;
        try {
            log.info("\n");
            log.info("********** Begin  -- Processing Mainframe Data ********** \n");
            MainframeClientPCF mainframeClientPCF = new MainframeClientPCF();
            mainframeClientPCF.open();
            mainframeClientPCF.close();
            processResult = "Scrape Processing completed on PCF!";
            log.info("********** End    -- Processing Mainframe Data ********** ");
            log.info("\n");
        } catch (Exception e) {
            processResult = "Error Processing -- " + e.getLocalizedMessage();

            log.info("Error Processing -- " + e.getLocalizedMessage() + "\n");
            log.info("********** End    -- Processing Mainframe Data ********** ");

        }
        return processResult;
    }

    @RequestMapping("/scrapefieldlocal")
    public @ResponseBody String scrapefieldlocal() {

        String processResult;
        try {
            log.info("********** Begin  -- Processing Mainframe Data ********** ");

            MainframeClientFieldLocal mainframeClient = new MainframeClientFieldLocal();
            mainframeClient.open();
            // mainframeClient.close();
            processResult = "Scrape Processing completed locally!";

            log.info("********** End    -- Processing Mainframe Data ********** ");
        } catch (Exception e) {
            processResult = "Error Processing -- " + e.getLocalizedMessage();
            log.info("********** End    -- Processing Mainframe Data ********** ");
        }
        return processResult;
        // return "Hello world, Scraping test app!";
    }

    @RequestMapping("/scrapefieldpcf")
    public @ResponseBody String scrapefieldpcf() {

        String processResult;
        try {
            log.info("********** Begin  -- Processing Mainframe Data ********** ");

            MainframeClientFieldPCF mainframeClient = new MainframeClientFieldPCF();
            mainframeClient.open();
            mainframeClient.close();
            processResult = "Scrape Processing completed locally!";

            log.info("********** End    -- Processing Mainframe Data ********** ");
        } catch (Exception e) {
            processResult = "Error Processing -- " + e.getLocalizedMessage();
            log.info("********** End    -- Processing Mainframe Data ********** ");
        }
        return processResult;
        // return "Hello world, Scraping test app!";
    }

    @RequestMapping("/scrapefromjson")
    public @ResponseBody String ScrapeFromJson() {

        String processResult;
        try {
            log.info("********** Begin  -- Processing Mainframe Data ********** ");
            String jsonfileName = "fixtures/jagacy/data/JsonStepsWithTestName_TC1.json";
            MainframeClientLocalUsingJSON mainframeClientJson = new MainframeClientLocalUsingJSON();
            mainframeClientJson.readAndExecuteSteps(jsonfileName);
            processResult = "Scrape Processing completed locally!";

            log.info("********** End    -- Processing Mainframe Data ********** ");
        } catch (Exception e) {
            processResult = "Error Processing -- " + e.getLocalizedMessage();
            log.info("********** End    -- Processing Mainframe Data ********** ");
        }
        return processResult;
        // return "Hello world, Scraping test app!";
    }
}
