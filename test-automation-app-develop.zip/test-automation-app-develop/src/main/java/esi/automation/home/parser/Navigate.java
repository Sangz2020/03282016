package esi.automation.home.parser;



import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;


public class Navigate {
	public static WebDriver driver;	
    public static final String USERNAME = "qahub";
    public static final String ACCESS_KEY = "053d3443-b0cf-41ef-997d-bf97afc16725";
    public static final String URL = "http://" + USERNAME + ":" + ACCESS_KEY + "@ch3ar028399.express-scripts.com:4445";
  //  public static final String Jenkins_URL = "http://"+System.getenv("SAUCE_USERNAME")+":"+System.getenv("SAUCE_ACCESS_KEY")+"@ch3ar028399.express-scripts.com:4445";        

    public static String strException;
    static String driverPath;
    static{
    	driverPath = System.getProperty("user.dir") + "\\src\\main\\resources\\fixtures\\drivers\\";
    	
    }
    
  
    public static WebDriver getIEBrowser(){
    	DesiredCapabilities ieCap = DesiredCapabilities.internetExplorer();
        ieCap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
        System.setProperty("webdriver.ie.driver", String.valueOf(driverPath)
                + "IEDriverServer.exe");
        Navigate.driver = new InternetExplorerDriver(ieCap);
    	return Navigate.driver;
    	}
    
    public static WebDriver getChromeBrowser(){
    	DesiredCapabilities capabilities = DesiredCapabilities.chrome();
        capabilities.setCapability("ensureCleanSession", true);
        System.setProperty("webdriver.chrome.driver", String.valueOf(driverPath)
                + "chromedriver.exe");
        Navigate.driver = new ChromeDriver();
        return Navigate.driver;
    	}
    
    public static WebDriver getIEBrowserSaucelabs() throws MalformedURLException{
    	 DesiredCapabilities ieCap = DesiredCapabilities.internetExplorer();
         
         ieCap.setCapability(InternetExplorerDriver.INTRODUCE_FLAKINESS_BY_IGNORING_SECURITY_DOMAINS, true);
         System.setProperty("webdriver.ie.driver", String.valueOf(WebUtility.driverPath)
                 + "IEDriverServer.exe");
         
         ieCap.setCapability("platform", "Windows 7");
         ieCap.setCapability("version", "11.0");
                           
          Navigate.driver = new RemoteWebDriver(new URL(URL), ieCap);                    
         
        // to be used while calling from Jenkins 
        /* Webdriver driver = new RemoteWebDriver(new URL(Jenkins_URL), ieCap);
         ieCap.setBrowserName(System.getenv("SELENIUM_BROWSER"));
         ieCap.setVersion(System.getenv("SELENIUM_VERSION"));
         ieCap.setCapability(CapabilityType.PLATFORM, System.getenv("SELENIUM_PLATFORM"));
                                           */		            
          return Navigate.driver;
    	}
    
        
    public static WebDriver getffBrowser(){
    	Navigate.driver = new FirefoxDriver();
    	return Navigate.driver;
    	}
    
    public static void SauceLabs(){
    	//Need a implementation
    }
    
   
    
    
    


}
