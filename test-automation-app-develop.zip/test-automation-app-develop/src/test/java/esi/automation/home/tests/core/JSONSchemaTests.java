/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.tests.core;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import java.io.File;
import java.io.FileReader;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.junit.Test;

import esi.automation.home.mainframe.MainframeClientLocalUsingJSON;
import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.parser.Parser;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */

public class JSONSchemaTests {

    String jsonSteps = "fixtures/jagacy/data/JsonSteps.json";
    String jsonWithMultipleTestSteps = "fixtures/jagacy/data/JsonStepsWithTestName_TC1.json";
    String jsonTestWith1Step = "fixtures/jagacy/data/JsonTestWith1Step.json";

    @Test
    public void givenValidInput_checkJSONFileExists() throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(jsonSteps).getFile());
        assertEquals(file.exists(), true);

    }

    @Test
    public void givenValidInput_checkJSONDataStepsWithSucess() throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(jsonSteps).getFile());
        JSONParser jsonParser = new JSONParser();
        JSONArray jsonArray = (JSONArray) jsonParser.parse(new FileReader(file));

        assertEquals(jsonArray.size(), 82);

    }

    @Test
    public void givenValidInput_checkJSONElementWithSucess() throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(jsonWithMultipleTestSteps).getFile());

        JSONParser jsonParser = new JSONParser();
        Object obj = jsonParser.parse(new FileReader(file));

        JSONObject jsonObject = (JSONObject) obj;
        JSONObject jsonChildObject = (JSONObject) jsonObject.get("testCase");
        String jsonChildcuratorObject = (String) jsonChildObject.get("curator");
        String jsonObjectname = (String) jsonChildObject.get("name");

        JSONObject jsonChildObjectConfiguration = (JSONObject) jsonChildObject.get("configuration");
        String jsonStringScreenshot = (String) jsonChildObjectConfiguration.get("screenshots");

        String jsonStringHost = (String) jsonChildObjectConfiguration.get("host");

        JSONArray testSteps = (JSONArray) jsonChildObject.get("testSteps");
        assertTrue(jsonChildcuratorObject != null);
        assertTrue(jsonObjectname != null);
        assertTrue(jsonStringScreenshot != null);
        assertTrue(jsonStringHost != null);
        // assertEquals(testSteps.size(), 82);
        // System.out.println("This is whole - " + jsonObject);
        // System.out.println("This is jsonChildObject - " + jsonChildObject);
        // System.out.println("This is curator - " + jsonChildcuratorObject);
        // System.out.println("This is name - " + jsonObjectname);
        // System.out.println("This is host - " + jsonStringHost);
        // System.out.println("This is testSteps - " + testSteps);
    }

    public void givenValidInput_ExecuteParserWithSucess() throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(jsonWithMultipleTestSteps).getFile());
        Parser parser = new Parser();
        MainframeTestCase testCase = parser.parse(file);
        assertTrue(testCase.getCurator() != null);
        // assertEquals(testCase.getTestSteps().size(), 82);

    }
    @Test
    public void givenValidInputRun_MainframeClientLocalUsingJSON() throws Exception {

        MainframeClientLocalUsingJSON mainframeClientJson = new MainframeClientLocalUsingJSON();
        mainframeClientJson.readAndExecuteSteps(jsonWithMultipleTestSteps);
        // mainframeClientJson.readAndExecuteSteps(jsonTestWith1Step);
    }

}
