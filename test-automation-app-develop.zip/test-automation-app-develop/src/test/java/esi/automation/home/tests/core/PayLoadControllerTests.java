/**
 * @ProjectDesc :Test Automation Project.
 */
package esi.automation.home.tests.core;

import static org.junit.Assert.assertTrue;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.standaloneSetup;

import java.io.File;

import org.junit.Before;
import org.junit.Test;
import org.springframework.test.web.servlet.MockMvc;

import esi.automation.home.core.PayLoadController;
import esi.automation.home.model.MainframeTestCase;
import esi.automation.home.model.ResponseResult;
import esi.automation.home.parser.Executer;
import esi.automation.home.parser.Parser;

/**
 * @AuthorName : Imran - ef5191
 * @DateCreated : Dec 30, 2016
 */
public class PayLoadControllerTests {

    String jsonSteps = "fixtures/jagacy/data/JsonSteps.json";
    String jsonWithMultipleTestSteps = "fixtures/jagacy/data/JsonStepsWithTestName_TC1.json";
    String jsonTestWith1Step = "fixtures/jagacy/data/JsonTestWith1Step.json";

    private MockMvc mockMvc;

    @Before
    public void setup() throws Exception {

        this.mockMvc = standaloneSetup(new PayLoadController()).build();
    }

    // Test new parser changes.
    @Test
    public void givenValidInput_ExecuteParserWithSucess() throws Exception {

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(jsonTestWith1Step).getFile());

        Parser parser = new Parser();
        MainframeTestCase testCase = parser.parse(file);
        assertTrue(testCase.getCurator() != null);

    }

    // Test Executer of new parser changes.
    public void givenValidInput_ExecuterRunWithSucess() throws Exception {

        ResponseResult responseResult = null;
        Executer executor = null;

        ClassLoader classLoader = getClass().getClassLoader();
        File file = new File(classLoader.getResource(jsonTestWith1Step).getFile());

        Parser testautomationParser = new Parser();
        executor = Executer.getInstance(testautomationParser.parse(file));
        responseResult = executor.execute();
        assertTrue(responseResult.getResponseResultList().size() == 3);

    }

    // Test new Payload Controller changes.
    @Test
    public void simple() throws Exception {

        standaloneSetup(new PayLoadController()).build().perform(get("/process/simple")).andExpect(status().isOk())
                .andExpect(content().contentType("text/plain;charset=ISO-8859-1"))
                .andExpect(content().string("Hello world!"));
    }

}
